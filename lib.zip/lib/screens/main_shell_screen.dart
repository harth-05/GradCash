import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/finance_provider.dart';
import '../utils/constants.dart';
import 'students_tab.dart';
import 'expenses_tab.dart';
import 'sponsors_tab.dart';
import 'statistics_tab.dart';
import 'settings_tab.dart';

class MainShellScreen extends StatefulWidget {
  const MainShellScreen({super.key});

  @override
  State<MainShellScreen> createState() => _MainShellScreenState();
}

class _MainShellScreenState extends State<MainShellScreen> {
  int _currentIndex = 4; // Start with Students (index 4 since we are RTL and list them right-to-left)
  // Let's actually define them logically and select the default tab.
  // Standard list of tabs:
  // 0: Settings, 1: Statistics, 2: Sponsors, 3: Expenses, 4: Students (Arabic RTL standard)
  
  final List<Widget> _tabs = [
    const SettingsTab(),
    const StatisticsTab(),
    const SponsorsTab(),
    const ExpensesTab(),
    const StudentsTab(),
  ];

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<FinanceProvider>(context);
    final isDark = provider.isDarkMode;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: IndexedStack(
          index: _currentIndex,
          children: _tabs,
        ),
        bottomNavigationBar: NavigationBarTheme(
          data: NavigationBarThemeData(
            indicatorColor: isDark 
                ? AppConstants.accentColor.withValues(alpha: 0.2) 
                : AppConstants.primaryColor.withValues(alpha: 0.1),
            labelTextStyle: WidgetStateProperty.resolveWith((states) {
              return const TextStyle(
                fontFamily: 'Cairo',
                fontSize: 12,
                fontWeight: FontWeight.bold,
              );
            }),
          ),
          child: NavigationBar(
            selectedIndex: _currentIndex,
            onDestinationSelected: (index) {
              setState(() {
                _currentIndex = index;
              });
            },
            destinations: const [
              NavigationDestination(
                icon: Icon(Icons.settings_outlined),
                selectedIcon: Icon(Icons.settings, color: AppConstants.accentColor),
                label: 'الإعدادات',
              ),
              NavigationDestination(
                icon: Icon(Icons.analytics_outlined),
                selectedIcon: Icon(Icons.analytics, color: AppConstants.accentColor),
                label: 'الإحصائيات',
              ),
              NavigationDestination(
                icon: Icon(Icons.card_giftcard_outlined),
                selectedIcon: Icon(Icons.card_giftcard, color: AppConstants.accentColor),
                label: 'الداعمين',
              ),
              NavigationDestination(
                icon: Icon(Icons.account_balance_wallet_outlined),
                selectedIcon: Icon(Icons.account_balance_wallet, color: AppConstants.accentColor),
                label: 'المصروفات',
              ),
              NavigationDestination(
                icon: Icon(Icons.people_outline),
                selectedIcon: Icon(Icons.people, color: AppConstants.accentColor),
                label: 'الطلاب',
              ),
            ],
          ),
        ),
      ),
    );
  }
}
